# FarmLeadership Codex Package

This package is a practical blueprint for turning a fresh Ghost install into **FarmLeadership.com**, a high-trust, white-hat content business about what farming teaches leadership.

## What is in here

- `farmleadership_codex_program.md`
  - The full strategy, UX, content, monetization, SEO, and implementation plan
- `codex_master_prompt.md`
  - A paste-ready instruction set for Codex or another coding agent
- `starter/theme/`
  - A lightweight custom Ghost theme scaffold with:
    - custom homepage
    - lesson-focused sections
    - sidecar launcher
    - custom theme settings
    - routes file
- `starter/sidecar/`
  - A simple content-sync service that can listen for Ghost webhooks and export your Ghost posts into a corpus for a Cheshire Cat style assistant

## What this package is designed to do

1. Make the site feel **earned, human, and memorable**
2. Grow traffic using **people-first, white-hat marketing**
3. Convert attention into **email subscribers, members, and digital product revenue**
4. Add a **Cheshire Cat sidecar** without turning the site into low-value AI sludge
5. Give Codex enough direction to build the site in controlled, reviewable phases

## Recommended operating principle

Let AI help with:
- discovery
- summaries
- reading paths
- draft assistance
- content repackaging into drafts

Do **not** let AI auto-publish large volumes of thin posts. The site should feel like it comes from a real farmer with real judgment, not a content factory.

## Suggested next move

Open `codex_master_prompt.md`, paste it into Codex in the root of your Ghost theme repo or working directory, and have it execute in phases with testing after each phase.
