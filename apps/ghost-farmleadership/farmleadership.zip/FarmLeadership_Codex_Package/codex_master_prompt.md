
# Codex Master Prompt for FarmLeadership.com

Paste everything below into Codex while working in the root of your Ghost theme or project directory.

---

You are building **FarmLeadership.com**, a premium Ghost-based content site about what farming teaches leadership.

Before changing files, read these local files if present:

- `README.md`
- `farmleadership_codex_program.md`

Then follow this operating mode:

1. Propose a short phase plan before editing files.
2. Work in small, reviewable phases.
3. Prefer minimal, clean changes over sprawling complexity.
4. Preserve Ghost compatibility and theme validation.
5. Use vanilla HTML, CSS, and lightweight JavaScript unless a dependency is clearly justified.
6. After each phase, summarize:
   - files changed
   - what was implemented
   - how to test it
   - any risks or assumptions
7. Verify your work whenever possible.
8. Do not introduce heavy client-side frameworks.
9. Do not build AI-driven auto-publishing.
10. The site must remain white-hat, people-first, fast, and accessible.

## Product intent

This site should feel like:
- grounded
- human
- editorial
- memorable
- rich but fast
- practical, not corporate

This site should not feel like:
- a generic theme
- a motivational blog with farm wallpaper
- AI sludge
- over-animated marketing fluff

## Strategic positioning

The core promise is:

**What the farm teaches about leadership.**

Supporting idea:

**Field-tested lessons on stewardship, trust, timing, and building what lasts.**

## Audience

Primary audience:
- founders
- owners
- managers
- operators
- team leaders

Secondary audience:
- people in leadership transition
- people burned out on abstract leadership advice
- community, education, and nonprofit leaders

## Major site goals

1. Build trust fast
2. Convert visitors to email subscribers
3. Support paid memberships and digital products
4. Create a distinctive content experience
5. Add a Cheshire Cat sidecar as a discovery assistant
6. Keep the author’s human voice at the center

## Technical goals

Use Ghost capabilities wherever possible:
- custom homepage with `home.hbs`
- custom routes via `routes.yaml`
- custom theme settings in `package.json`
- native Portal for signup and memberships
- native search support
- clean theme partials
- strong mobile layout
- minimal JavaScript
- lazy-loaded sidecar widget

## Content architecture

Create or support these sections:

- Home
- Start Here
- Lessons / Field Notes
- Playbooks
- Newsletter
- About
- Speaking / Work With Me
- Topic hubs such as trust, stewardship, timing, resilience

Use tags and routing patterns that make this manageable in Ghost.

## Design direction

Design should feel:
- editorial
- earthy
- modern
- spacious
- trustworthy
- tactile without being cluttered

Use:
- clean typography
- restrained accent colors
- subtle texture
- clear hierarchy
- image-led storytelling
- card systems for posts and resources

Avoid:
- giant sliders
- heavy parallax
- noisy motion
- unnecessary dependencies
- template clutter

## Homepage requirements

Homepage should include:
- hero section
- strong CTA
- secondary CTA
- featured “today’s field lesson”
- six leadership pillars
- short founder story strip
- featured posts
- newsletter CTA
- subtle Cheshire Cat invite
- useful footer

## Cheshire Cat sidecar requirements

Important:
The Cheshire Cat is a **guide**, not the author.

Build the front-end sidecar launcher and integration points so that:
- it is lazy-loaded only after user intent
- it can pass current page URL and title
- it has a concise launcher label
- it does not block rendering
- it can be disabled with a theme setting
- it can link people to relevant posts or signup pages

Do **not** implement auto-generated public post publishing.

## White-hat rules

Every implementation choice should align with:
- people-first content
- original experience
- no scaled content spam
- clear disclosures
- accessibility
- performance
- straightforward UX

## Accessibility and performance requirements

Aim for:
- strong contrast
- visible focus styles
- keyboard-friendly nav
- good mobile spacing
- semantic HTML
- low script weight
- image optimization hooks
- clean heading structure

Keep Core Web Vitals in mind:
- fast LCP
- low CLS
- good interactivity

## Phased execution order

### Phase 1
Set up or refine:
- `package.json`
- `routes.yaml`
- core layout files
- partials structure
- basic navigation
- custom theme settings

### Phase 2
Build homepage experience:
- hero
- pillars
- featured content
- story strip
- newsletter CTA
- footer

### Phase 3
Build archives and topic hub templates:
- `index.hbs`
- `index-playbooks.hbs`
- `channel-topic.hbs`
- reading path / related content modules

### Phase 4
Improve post and page templates:
- stronger article layout
- CTA zones
- related resources
- sidecar invite

### Phase 5
Integrate sidecar front-end:
- launcher
- lazy loader
- contextual data handoff
- config driven behavior

### Phase 6
Polish:
- metadata
- structured data where appropriate
- accessibility pass
- responsive pass
- cleanup and documentation

## File guidance

If files do not exist, create them.
If files already exist, refactor carefully and preserve working behavior.

Likely files:
- `default.hbs`
- `home.hbs`
- `index.hbs`
- `post.hbs`
- `page.hbs`
- `channel-topic.hbs`
- `index-playbooks.hbs`
- `partials/*.hbs`
- `assets/css/screen.css`
- `assets/js/main.js`
- `package.json`
- `routes.yaml`

## Sidecar integration guidance

If a sidecar endpoint is configured, expect a base URL in a theme setting such as:
- `@custom.cat_sidecar_url`

Front-end integration should:
- render a launcher button
- open a panel or iframe
- pass page context via query params or postMessage
- degrade gracefully if endpoint is missing
- not break without JS

## Content tone hints for UI copy

Use short, grounded copy:
- “Get the weekly Field Notes”
- “Start here”
- “Ask the Cat”
- “Today’s field lesson”
- “What the farm teaches about leadership”
- “Field-tested lessons on stewardship, trust, timing, and building what lasts”

Avoid hypey copy:
- “10x your leadership”
- “Unlock your best self”
- “Transform instantly”
- “Crush your goals”

## Output format after each phase

After each phase:
1. Summarize what you changed
2. Explain how to test it
3. List any follow-up improvements
4. Stop for review unless the next phase is very small and low risk

Start by inspecting the current project structure and proposing Phase 1.
