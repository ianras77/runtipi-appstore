# Sidecar starter

This folder contains a simple starter service that helps keep a Ghost site and a Cheshire Cat style assistant in sync.

## What it does

- exposes `POST /ghost-webhook`
- accepts Ghost webhook calls
- fetches published posts from the Ghost Content API
- writes a normalized corpus to `./corpus`
- optionally forwards the corpus to another endpoint

## Why this exists

Ghost is your publishing system.
The sidecar should not scrape HTML blindly every time a user asks a question.

This sync service gives the AI assistant a cleaner content feed.

## Environment variables

- `PORT` — default `8787`
- `GHOST_URL` — example `https://farmleadership.com`
- `GHOST_CONTENT_API_KEY` — Content API key from Ghost custom integration
- `CAT_SYNC_ENDPOINT` — optional endpoint to receive the normalized corpus payload

## Endpoints

- `GET /health`
- `POST /ghost-webhook`
- `POST /sync`

## Notes

This starter is intentionally minimal:
- no database
- no queue
- no auth
- no webhook signature validation

Before production use, add:
- shared-secret verification
- retry logic
- logging
- rate limiting
- structured error reporting
