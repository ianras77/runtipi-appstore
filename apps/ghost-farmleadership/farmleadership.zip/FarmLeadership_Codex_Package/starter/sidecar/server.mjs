import http from 'node:http';
import { writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const PORT = Number(process.env.PORT || 8787);
const GHOST_URL = (process.env.GHOST_URL || '').replace(/\/+$/, '');
const GHOST_CONTENT_API_KEY = process.env.GHOST_CONTENT_API_KEY || '';
const CAT_SYNC_ENDPOINT = process.env.CAT_SYNC_ENDPOINT || '';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const corpusDir = join(__dirname, 'corpus');

async function ensureCorpusDir() {
  await mkdir(corpusDir, { recursive: true });
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8') || '{}';
  try {
    return JSON.parse(raw);
  } catch {
    return { raw };
  }
}

function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload, null, 2);
  res.writeHead(statusCode, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(body);
}

async function fetchGhostPosts() {
  if (!GHOST_URL || !GHOST_CONTENT_API_KEY) {
    throw new Error('Missing GHOST_URL or GHOST_CONTENT_API_KEY');
  }

  const url = new URL('/ghost/api/content/posts/', GHOST_URL);
  url.searchParams.set('key', GHOST_CONTENT_API_KEY);
  url.searchParams.set('limit', 'all');
  url.searchParams.set('include', 'tags,authors');

  const response = await fetch(url, {
    headers: {
      'Accept-Version': 'v6.0'
    }
  });

  if (!response.ok) {
    throw new Error(`Ghost Content API failed with ${response.status}`);
  }

  const json = await response.json();
  return json.posts || [];
}

function normalizePost(post) {
  return {
    id: post.id,
    slug: post.slug,
    title: post.title,
    url: post.url,
    excerpt: post.excerpt,
    published_at: post.published_at,
    updated_at: post.updated_at,
    html: post.html,
    plaintext: post.plaintext,
    custom_excerpt: post.custom_excerpt,
    tags: (post.tags || []).map((tag) => ({
      name: tag.name,
      slug: tag.slug,
      visibility: tag.visibility
    })),
    authors: (post.authors || []).map((author) => ({
      name: author.name,
      slug: author.slug
    }))
  };
}

function postToMarkdown(post) {
  const tagLine = (post.tags || []).map((tag) => tag.name).join(', ');
  const authorLine = (post.authors || []).map((author) => author.name).join(', ');

  return `# ${post.title}

URL: ${post.url}
Published: ${post.published_at || ''}
Updated: ${post.updated_at || ''}
Authors: ${authorLine}
Tags: ${tagLine}

Excerpt:
${post.excerpt || ''}

Plain text:
${post.plaintext || ''}
`;
}

async function persistCorpus(posts) {
  await ensureCorpusDir();

  const normalized = posts.map(normalizePost);
  await writeFile(join(corpusDir, 'index.json'), JSON.stringify(normalized, null, 2), 'utf8');

  await Promise.all(
    normalized.map((post) => {
      const filename = `${post.slug}.md`;
      return writeFile(join(corpusDir, filename), postToMarkdown(post), 'utf8');
    })
  );

  return normalized;
}

async function forwardToCat(corpus) {
  if (!CAT_SYNC_ENDPOINT) return { forwarded: false };

  const response = await fetch(CAT_SYNC_ENDPOINT, {
    method: 'POST',
    headers: {
      'content-type': 'application/json; charset=utf-8'
    },
    body: JSON.stringify({
      source: 'ghost',
      corpus
    })
  });

  return {
    forwarded: true,
    status: response.status
  };
}

async function runSync() {
  const posts = await fetchGhostPosts();
  const corpus = await persistCorpus(posts);
  const cat = await forwardToCat(corpus);
  return {
    posts_synced: corpus.length,
    ...cat
  };
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host}`);

    if (req.method === 'GET' && url.pathname === '/health') {
      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'POST' && (url.pathname === '/ghost-webhook' || url.pathname === '/sync')) {
      const payload = await readJson(req);
      const result = await runSync();

      return sendJson(res, 200, {
        ok: true,
        trigger: url.pathname,
        webhook_payload_received: payload,
        result
      });
    }

    return sendJson(res, 404, { ok: false, error: 'Not found' });
  } catch (error) {
    return sendJson(res, 500, {
      ok: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

server.listen(PORT, () => {
  console.log(`FarmLeadership sidecar sync listening on :${PORT}`);
});
