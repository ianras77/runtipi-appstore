# Theme starter

This is a lightweight starter Ghost theme scaffold for FarmLeadership.com.

## Files

- `package.json` — theme metadata and custom settings
- `routes.yaml` — custom homepage, field notes archive, playbooks archive, and topic channels
- `default.hbs` — base layout
- `home.hbs` — handcrafted homepage
- `index.hbs` — field notes archive
- `index-playbooks.hbs` — playbooks archive
- `channel-topic.hbs` — reusable channel template for topic hubs
- `post.hbs` — article template
- `page.hbs` — standard page template
- `partials/` — reusable UI sections
- `assets/css/screen.css` — starter styling
- `assets/js/main.js` — responsive nav + sidecar lazy loader

## Notes

This starter is intentionally simple.
It is meant to be:
- uploaded to Ghost as a base theme
- extended by Codex or a developer
- performance-conscious
- easy to reason about

## Follow-up work recommended

- add `custom-start-here.hbs`
- add `custom-newsletter.hbs`
- add `custom-membership.hbs`
- wire richer topic-specific intro copy
- add richer related-post logic
- add better social preview defaults
- validate and refine structured data
- QA with GScan after each significant change
