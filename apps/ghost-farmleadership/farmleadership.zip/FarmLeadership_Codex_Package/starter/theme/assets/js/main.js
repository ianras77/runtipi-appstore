document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.site-nav');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('is-open');
    });
  }

  const sidecar = document.querySelector('.cat-sidecar');
  if (!sidecar) return;

  const launchers = document.querySelectorAll('.sidecar-open');
  const close = sidecar.querySelector('.sidecar-close');
  const panel = sidecar.querySelector('.cat-panel');
  const mount = sidecar.querySelector('[data-sidecar-mount]');
  const baseUrl = sidecar.dataset.sidecarUrl;
  const pageUrl = sidecar.dataset.pageUrl;
  const pageTitle = sidecar.dataset.pageTitle;

  let iframeLoaded = false;

  const loadIframe = () => {
    if (iframeLoaded || !baseUrl || !mount) return;
    const src = new URL(baseUrl);
    src.searchParams.set('source', 'farmleadership-theme');
    if (pageUrl) src.searchParams.set('page', pageUrl);
    if (pageTitle) src.searchParams.set('title', pageTitle);

    const iframe = document.createElement('iframe');
    iframe.className = 'cat-embed';
    iframe.loading = 'lazy';
    iframe.title = 'FarmLeadership guide assistant';
    iframe.src = src.toString();

    mount.innerHTML = '';
    mount.appendChild(iframe);
    iframeLoaded = true;
  };

  const openPanel = () => {
    if (!panel) return;
    loadIframe();
    panel.hidden = false;
    launchers.forEach((btn) => btn.setAttribute('aria-expanded', 'true'));
  };

  const closePanel = () => {
    if (!panel) return;
    panel.hidden = true;
    launchers.forEach((btn) => btn.setAttribute('aria-expanded', 'false'));
  };

  launchers.forEach((btn) => {
    btn.addEventListener('click', openPanel);
  });

  if (close) {
    close.addEventListener('click', closePanel);
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closePanel();
  });
});
