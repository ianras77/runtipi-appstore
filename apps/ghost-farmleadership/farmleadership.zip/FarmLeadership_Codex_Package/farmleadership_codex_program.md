
# FarmLeadership.com Ghost Growth Codex

## 1. Core thesis

**FarmLeadership.com should not feel like a motivational blog wearing a tractor costume.**

It should feel like a place where leadership wisdom is earned through weather, work, stewardship, timing, uncertainty, maintenance, care, and consequence.

The site wins if visitors think:

- “This is different from the usual leadership sludge.”
- “This person actually lives the ideas.”
- “I want more of this in my inbox.”
- “I trust this enough to buy a playbook, join a membership, or recommend it.”

The site loses if it feels:

- generic
- corporate
- politically coded
- nostalgic in a fake way
- overproduced
- over-automated
- stuffed with AI filler

Your advantage is not that you can talk *about* leadership.

Your advantage is that you can say:

> I do things every day that force me to practice leadership under pressure, uncertainty, and limits. Here is what the farm taught me this week.

That is the engine.

---

## 2. Cultural sweet spot

People are tired of frictionless advice from people who have never had dirt under their fingernails.

The modern leadership market is crowded with:
- abstract frameworks
- expensive jargon
- hustle worship
- vague inspiration
- “thought leadership” with no cost attached

The counter-position is strong:

**Leadership as stewardship.  
Leadership as timing.  
Leadership as maintenance.  
Leadership as care under constraint.  
Leadership as patience with consequence.**

That message lands right now because audiences are hungry for:
- grounded authority
- embodied wisdom
- slower, saner ambition
- trustworthy voices
- practical frameworks that feel human

### Emotional tone to aim for

- Plainspoken, not simplistic
- Warm, not corny
- Wise, not preachy
- Poetic in flashes, practical most of the time
- Visually rich, but never luxury-fake
- Rural without cosplay
- Confident without swagger

### Brand angle in one sentence

**What farming teaches about leading people, making decisions, weathering uncertainty, and building something that lasts.**

### Better-than-average tagline options

Pick one and commit:

1. **Leadership you can plant, tend, and harvest.**
2. **Field-tested lessons for leading people and building what lasts.**
3. **What the farm teaches about leadership.**
4. **Stewardship, timing, trust, and grit.**
5. **Less jargon. More seasons. Better leadership.**

My favorite for the homepage hero:

**What the farm teaches about leadership.**  
*Field-tested lessons on stewardship, trust, timing, and building what lasts.*

That line is clean, searchable, memorable, and broad enough to grow.

---

## 3. Who the site is really for

Do not target “everyone interested in leadership.” That is a fog machine.

Target these four audiences in order:

### Primary audience
**Owners, founders, operators, managers, and team leaders** who want more grounded leadership thinking.

Why they buy:
- they lead people
- they make hard calls
- they are allergic to fluff
- they want principles they can use immediately

### Secondary audience
**People in transition**  
New managers, burned-out executives, people rethinking work, men and women looking for sturdier models of responsibility.

Why they subscribe:
- they want meaning and competence
- they want leadership language that feels moral and real

### Third audience
**Church, nonprofit, education, and community leaders**
They often resonate with stewardship language, practical authority, and service.

### Fourth audience
**Farm-curious general readers**
They arrive for the farm lens and stay for the leadership insights.

---

## 4. Positioning statement

Use this internally. Not necessarily on the site.

> FarmLeadership.com is a media and membership business that teaches leadership through the lived realities of farming: seasons, systems, stewardship, weather, risk, repair, boundaries, patience, and care. It serves people who want leadership lessons grounded in real work, not corporate theater.

---

## 5. White-hat marketing rules

This is the non-negotiable backbone.

### Rule 1: Write for humans first
Every post should solve one honest question, deepen one truth, or tell one real story.

### Rule 2: Firsthand beats paraphrased
The strongest content is:
- stories from your farm
- lessons from mistakes
- practical examples from chores, breakdowns, harvests, animals, seasons, equipment, weather, staffing, planning
- original photos and short videos
- your own diagrams, checklists, templates, and field notes

### Rule 3: AI can accelerate, not replace
Use AI for:
- outlines
- title options
- summaries
- internal linking suggestions
- newsletter repackaging
- transcripts to drafts
- sidecar Q&A

Do not use AI to:
- mass-produce shallow keyword pages
- auto-publish without review
- clone what other sites already said
- stuff the blog with “top 50 leadership lessons from farming” pages that all say the same thing

### Rule 4: Search intent before keyword volume
Search is not a slot machine.
Build content around:
- real questions people ask
- problems leaders face
- phrases that naturally match your point of view

### Rule 5: Every monetization path must feel earned
No shady scarcity.  
No fake testimonials.  
No vague promises.  
No affiliate page with zero lived opinion.

### Rule 6: Accessibility and performance are part of trust
Fast pages, readable type, proper contrast, obvious navigation, transcripts, alt text, and a sane mobile layout are not polish. They are leadership.

### Rule 7: Be transparent
If you use affiliate links, disclose them clearly.
If AI helps draft or summarize internal workflows, keep the public voice human and reviewed.

---

## 6. Content pillars

Do not organize the site around “blog categories” alone. Organize it around recurring human problems.

### Pillar A: Stewardship
Questions:
- What am I responsible for?
- How do I care for people and systems over time?
- How do I leave something better than I found it?

Farm metaphors:
- soil health
- rotation
- maintenance
- feed and water
- protecting future yield

### Pillar B: Timing
Questions:
- When do I push?
- When do I wait?
- How do I know when a decision is ripe?

Farm metaphors:
- planting windows
- weather shifts
- harvest timing
- acting before conditions are perfect

### Pillar C: Trust
Questions:
- How do I build trust slowly?
- How do I restore trust after mistakes?
- How do teams know I mean what I say?

Farm metaphors:
- fences
- gates
- daily care
- showing up in all weather
- consistent routines

### Pillar D: Systems and maintenance
Questions:
- How do leaders avoid preventable chaos?
- What maintenance are we skipping?
- How do small breakdowns become large failures?

Farm metaphors:
- equipment checks
- broken gates
- feed schedules
- irrigation
- preventative care

### Pillar E: Resilience under uncertainty
Questions:
- How do I lead when I cannot control outcomes?
- How do I stay steady during volatility?
- How do I make the next right move?

Farm metaphors:
- weather
- drought
- market swings
- pests
- injury
- contingencies

### Pillar F: People and culture
Questions:
- How do I correct without crushing?
- How do I set boundaries?
- How do I lead with warmth and authority?

Farm metaphors:
- tending vs forcing
- boundaries and fences
- team rhythms
- care with standards

---

## 7. Signature content franchises

A strong site has recurring formats. Formats train the audience.

### 1. Field Notes
Short, vivid observations from daily farm life tied to one leadership lesson.

Length:
600 to 1,000 words

Goal:
Top-of-funnel habit content

### 2. The Leadership Lesson in This Chore
A recurring series:
- mending fences
- checking water
- feeding animals
- planting
- culling
- repairing equipment
- managing weather days

Goal:
Shareable, memorable, search-friendly

### 3. Season Lessons
Quarterly / seasonal essays:
- Spring: beginnings, preparation, hope
- Summer: endurance, consistency, heat
- Fall: harvest, accountability, results
- Winter: reflection, repair, planning

Goal:
Brand depth and editorial identity

### 4. Playbooks
Highly practical actionable pieces:
- decision checklists
- team meeting frameworks
- boundary-setting scripts
- crisis response sheets
- leadership review templates

Goal:
Email capture and product ladder

### 5. Barn Talks
Audio or video reflections, simple and real, recorded in place.

Goal:
Build intimacy and authority

### 6. Ask the Field
Questions from readers answered through the farm lens.

Goal:
Community and SEO from real questions

### 7. The Week’s Weather / The Week’s Lesson
A simple recurring newsletter and homepage module.

Goal:
Consistency and distinctiveness

---

## 8. Site architecture

Build a site that feels more like a field guide than a standard blog.

## Primary nav

- Home
- Start Here
- Lessons
- Playbooks
- Newsletter
- About
- Speaking / Work With Me
- Search

Optional later:
- Membership
- Resources
- Podcast / Audio

## Core pages

### Home
Purpose:
Create emotional pull, clear positioning, and email conversion.

### Start Here
Purpose:
Guide new visitors into the best 5 to 7 pieces.

### Lessons
Purpose:
A curated hub of leadership essays and topic filters.

### Playbooks
Purpose:
High-intent practical resources, some free, some paid.

### Newsletter
Purpose:
Standalone signup page with clear promise and archive links.

### About
Purpose:
Why this site exists, why you, why farming, why leadership.

### Speaking / Work With Me
Purpose:
Active income lane that also enhances trust.

### Topic hubs
Examples:
- /topic/stewardship/
- /topic/trust/
- /topic/timing/
- /topic/decision-making/
- /topic/team-culture/

These are not just tag dumps. They need hand-shaped introductions and curated content.

---

## 9. Homepage blueprint

The homepage should feel like walking through a gate and realizing this place has a heartbeat.

## Section 1: Hero
Visual:
- full-width still image or very light muted loop video from the farm
- strong headline
- subhead
- one primary CTA
- one secondary CTA

Copy pattern:
Headline:
**What the farm teaches about leadership.**

Subhead:
**Field-tested lessons on stewardship, trust, timing, and building what lasts.**

CTAs:
- Get the weekly Field Notes
- Start here

## Section 2: “Today’s field lesson”
A highlighted recent post or manually chosen feature.

Use this as the “front porch” post.

## Section 3: The six pillars
Cards with:
- title
- one-line explanation
- link to topic hub

## Section 4: Your story
Not a long autobiography.
Just enough:
- I’m a farmer
- the farm keeps teaching me leadership
- this site is where I share what is true enough to keep

## Section 5: Featured lessons
Mix:
- 2 essays
- 2 short field notes
- 1 playbook
- 1 audio piece

## Section 6: Newsletter strip
Promise:
“A weekly note from the field about leadership, responsibility, decisions, and what lasts.”

## Section 7: Social proof
At launch, use qualitative trust instead of fake logos:
- reader quotes
- early replies
- “read by founders, managers, community leaders, and people building real things”
Only add company logos if they are real and approved.

## Section 8: Cheshire Cat sidecar invite
A subtle module:
“Not sure where to begin? Ask the Cat what lesson you need today.”

## Section 9: Footer
Keep it useful:
- best pages
- topic hubs
- subscribe
- disclosure
- privacy
- contact

---

## 10. Rich experience principles

The site should be immersive, but still fast.

### Good richness
- original photography
- short ambient farm video loops
- textured but restrained design
- interactive filters
- audio reflections
- illustrated pull quotes
- dynamic “lesson of the day”
- subtle seasonality in visuals
- field-journal card layouts
- sticky reading progress
- inline related questions
- tasteful motion on reveal

### Bad richness
- heavy autoplay video everywhere
- giant sliders
- slow parallax nonsense
- full-screen popups on arrival
- noisy background effects
- excessive script bloat

### Visual language
Aim for:
- texture without clutter
- generous whitespace
- earthy neutrals
- one strong accent color
- editorial typography
- clean hierarchy
- cards that feel like notes, not corporate tiles

### Seasonal design concept
A beautiful extra:
Switch subtle accent treatments by season:
- spring: fresh green
- summer: wheat gold
- fall: rust
- winter: slate

Use custom theme settings so you can override this manually.

---

## 11. Ghost implementation architecture

Ghost is a strong fit because the business model is already baked in:
- publishing
- newsletters
- memberships
- paid subscriptions
- search
- recommendations
- analytics
- theme customization
- API and webhooks

### Recommended structure

- Custom homepage on `/`
- Main public writing collection on `/field-notes/`
- Playbooks collection on `/playbooks/`
- Optional channels for topic hubs
- Native member signup through Portal
- Free and paid newsletters
- Search accessible in nav
- Custom sidecar loaded via theme partial

### Content model in Ghost

Use a combination of:
- collections
- public tags
- internal tags
- pages
- custom templates

#### Collections
Use collections for distinct content zones with different URLs.

Suggested:
- `/field-notes/`
- `/playbooks/`

#### Public tags
Use these for visible topics:
- stewardship
- trust
- timing
- resilience
- culture
- systems
- decision-making
- conflict
- repair
- patience

#### Internal tags
Use internal tags for editorial control:
- `#format-field-note`
- `#format-playbook`
- `#format-audio`
- `#feature-home`
- `#evergreen`
- `#lead-magnet`
- `#season-spring`
- `#season-summer`
- `#season-fall`
- `#season-winter`

#### Pages
Create pages for:
- about
- start-here
- newsletter
- membership
- speaking
- disclosures
- privacy

---

## 12. Recommended Ghost routing plan

Use a custom homepage and move the main post stream off root.

### Proposed `routes.yaml`

```yaml
routes:
  /: home
  /start-here/: page
  /newsletter/: page
  /membership/: page
  /speaking/: page

  /topic/trust/:
    controller: channel
    filter: tag:trust
    template: channel-topic
  /topic/stewardship/:
    controller: channel
    filter: tag:stewardship
    template: channel-topic
  /topic/timing/:
    controller: channel
    filter: tag:timing
    template: channel-topic
  /topic/resilience/:
    controller: channel
    filter: tag:resilience
    template: channel-topic

collections:
  /field-notes/:
    permalink: /field-notes/{slug}/
    template: index
    filter: tag:-hash-format-playbook+tag:-hash-format-audio
  /playbooks/:
    permalink: /playbooks/{slug}/
    template: index-playbooks
    filter: tag:hash-format-playbook

taxonomies:
  tag: /tag/{slug}/
  author: /author/{slug}/
```

### Why this structure works
- `/` becomes a handcrafted homepage
- `/field-notes/` becomes the main article archive
- `/playbooks/` separates practical resources from essays
- `/topic/.../` channels create evergreen hubs without changing post URLs

---

## 13. Theme file map

Suggested theme structure:

```text
starter/theme/
  assets/
    css/screen.css
    js/main.js
  partials/
    site-header.hbs
    site-footer.hbs
    home-hero.hbs
    featured-pillars.hbs
    featured-posts.hbs
    newsletter-cta.hbs
    cat-sidecar.hbs
  default.hbs
  home.hbs
  index.hbs
  post.hbs
  page.hbs
  custom-start-here.hbs
  custom-newsletter.hbs
  custom-membership.hbs
  channel-topic.hbs
  index-playbooks.hbs
  package.json
```

### Critical theme goals
- clear typography
- mobile-first layout
- fast image loading
- minimal JS by default
- lazy-load heavier modules
- lightweight sidecar launcher
- strong CTA patterns
- reusable partials

---

## 14. Custom theme settings to add

Ghost custom settings are one of the best ways to make the theme flexible without editing files each time.

Recommended settings:

- `brand_tagline`
- `hero_eyebrow`
- `hero_cta_text`
- `hero_cta_url`
- `secondary_cta_text`
- `secondary_cta_url`
- `season_mode`
- `home_feature_tag`
- `cat_enabled`
- `cat_sidecar_url`
- `cat_label`
- `show_video_hero`
- `hero_video_url`
- `newsletter_promise`
- `announcement_text`

### Example configuration

```json
{
  "config": {
    "posts_per_page": 12,
    "card_assets": true,
    "custom": {
      "brand_tagline": {
        "type": "text",
        "default": "Field-tested lessons on stewardship, trust, timing, and building what lasts."
      },
      "hero_eyebrow": {
        "type": "text",
        "default": "Farm Leadership"
      },
      "hero_cta_text": {
        "type": "text",
        "default": "Get the weekly Field Notes"
      },
      "hero_cta_url": {
        "type": "text",
        "default": "#/portal/signup"
      },
      "secondary_cta_text": {
        "type": "text",
        "default": "Start here"
      },
      "secondary_cta_url": {
        "type": "text",
        "default": "/start-here/"
      },
      "season_mode": {
        "type": "select",
        "options": ["spring", "summer", "fall", "winter", "manual"],
        "default": "manual"
      },
      "cat_enabled": {
        "type": "boolean",
        "default": true
      },
      "cat_sidecar_url": {
        "type": "text",
        "default": "https://cat.farmleadership.com"
      },
      "cat_label": {
        "type": "text",
        "default": "Ask the Cat"
      },
      "newsletter_promise": {
        "type": "text",
        "default": "A weekly note from the field about leadership, responsibility, decisions, and what lasts."
      }
    }
  }
}
```

---

## 15. Membership and monetization ladder

You asked for passive income, so the business model matters as much as the writing.

### Ladder stage 1: Free subscriber
Offer:
- weekly newsletter
- best essays
- occasional field notes
- free resource / starter playbook

Goal:
Build trust and repeat attention

### Ladder stage 2: Paid member
Offer:
- monthly premium playbook
- deeper essays
- audio reflections
- archive access
- members-only Q&A roundups
- printable leadership worksheets

### Ladder stage 3: Premium product
Offer:
- self-paced course
- leadership toolkit
- seasonal reflection journal
- “Leading Through the Seasons” workshop in recorded form

### Ladder stage 4: Active income
Offer:
- keynote
- workshop
- executive offsite session
- consulting / coaching

This is not passive, but it helps early revenue and social proof.

## Recommended offer names

### Free tier
**Field Notes**

### Paid tier option 1
**Steward’s Circle**

### Paid tier option 2
**Barn Loft**

### Paid tier option 3
**The Back Forty**

My vote:
- Free: **Field Notes**
- Paid: **Steward’s Circle**

It sounds grown, not gimmicky.

---

## 16. Product ideas that fit the brand

Start with products that are:
- fast to ship
- highly useful
- easy to explain
- aligned with your essays

### Strong first products

1. **The Farmer’s Leadership Playbook**
   - 40 to 70 pages
   - PDF + workbook
   - evergreen
   - premium lead magnet or low-ticket product

2. **Decision-Making in Bad Weather**
   - mini-course
   - how to lead under uncertainty

3. **Fences, Gates, and Boundaries**
   - scripts and principles for hard conversations
   - very buyable

4. **The Weekly Review from the Field**
   - Notion / PDF templates
   - leadership reflection ritual

5. **Seasons of Leadership**
   - digital workshop or audio series

### Weak early products
- generic merch
- random farm-themed mugs
- affiliate-heavy gear pages
- giant cohort course before audience fit
- expensive mastermind too early

---

## 17. Email strategy

Ghost is excellent here, so use it hard.

### Use at least two newsletters

1. **Field Notes**  
Free weekly editorial email

2. **Steward’s Circle**  
Paid deeper note, playbook, or audio reflection

### Email promise
Keep it simple:
- one useful lesson
- one human story
- one next step

### Welcome sequence
Build a 5-email sequence:

#### Email 1
Why the site exists

#### Email 2
What the farm has taught you about leadership

#### Email 3
Best 3 starter essays

#### Email 4
A practical worksheet or downloadable resource

#### Email 5
Invitation to paid tier or playbook

### Conversion rhythm
Do not pitch every week.
Use a rhythm like:
- 3 value-heavy sends
- 1 invitation send
- repeat

---

## 18. White-hat acquisition channels

### 1. Search
Focus on intent-rich topics:
- what farming teaches about leadership
- leadership lessons from farming
- stewardship leadership
- how to lead through uncertainty
- leadership and patience
- building trust as a leader
- why maintenance matters in leadership
- how to set boundaries as a leader

But do not over-optimize phrasing. Write naturally.

### 2. Newsletter cross-promotion
Use Ghost Recommendations and partnerships with:
- leadership newsletters
- resilience / operations newsletters
- founder newsletters
- rural / ag-adjacent publications
- faith and community leadership newsletters where appropriate

### 3. Podcast guesting
This is one of the best channels for a founder voice brand.
Pitch:
- leadership podcasts
- culture podcasts
- operations / management shows
- faith and character shows
- agricultural shows with crossover audiences

### 4. Short-form social
Repurpose into:
- quote cards
- short video field reflections
- carousel posts
- “one lesson from today’s chore” clips

### 5. Organic referrals
Build pages worth sharing:
- start here page
- best essays page
- one iconic flagship essay
- one standout playbook

### 6. Speaking
Use speaking as a growth channel, not just revenue.

---

## 19. Content plan for the first 90 days

You need enough content to feel substantial, but not a flood.

## Month 1: Foundations
Publish:
- homepage
- about
- start here
- newsletter page
- 6 cornerstone essays
- 4 short field notes
- 1 free playbook
- welcome email sequence

### Cornerstone essay ideas
1. What the farm teaches about leadership
2. Stewardship is a better word than ambition
3. Why good leaders fix small things early
4. Trust is built like a fence, one post at a time
5. Leadership under weather you cannot control
6. Seasons of leadership: when to push and when to wait

## Month 2: Rhythm
Publish weekly:
- 1 essay
- 1 field note
- 1 email

Ship:
- 1 audio reflection
- 1 premium playbook draft
- 3 short videos

## Month 3: Conversion
Publish:
- 4 essays
- 4 field notes
- 1 big flagship essay
- 1 paid product
- 1 members-only archive section
- 1 partnership campaign

---

## 20. SEO playbook that stays white-hat

### On-page approach
Every post should have:
- a clear promise in title
- a compelling meta description
- one main question it answers
- helpful subheads
- original photos or diagrams when relevant
- internal links to related essays and playbooks
- a clear CTA

### Topic hub approach
Create curated hubs around:
- trust
- timing
- stewardship
- resilience
- team culture
- decision-making
- maintenance
- conflict

Each hub should have:
- 200 to 500 words of original intro copy
- best articles
- a recommended reading order
- a CTA to subscribe

### Structured data
Prioritize:
- Article
- Organization
- WebSite
- SearchAction if your theme supports it cleanly

Do not rely on FAQ rich results for this niche.

### Link building, white-hat only
Earn links through:
- podcast appearances
- guest essays
- newsletter mentions
- original frameworks
- quotable flagship essays
- agricultural leadership angle that stands out

### Avoid
- buying links
- stuffing tags
- spinning AI pages
- low-value roundups
- “top 100 leadership quotes from farmers” junk

---

## 21. Accessibility and performance standards

Treat these as launch requirements, not “later.”

### Accessibility
- strong color contrast
- visible focus states
- keyboard-navigable menu
- alt text for all editorial images
- captions / transcript for audio and video
- 16px+ body type
- readable line length
- no essential hover-only actions

### Performance
Targets:
- LCP < 2.5s
- INP < 200ms
- CLS < 0.1

### Practical implementation notes
- lazy-load below-the-fold images
- use responsive image sizes
- keep hero video optional and compressed
- avoid heavy client-side frameworks
- inline critical theme CSS if needed
- defer nonessential JavaScript
- do not load the sidecar until user intent

---

## 22. Cheshire Cat sidecar strategy

This is where whimsy can actually help, but only if it has discipline.

## The role of the Cat

The Cat should be a:
- guide
- recommender
- explainer
- archive navigator
- reading-path builder
- conversion assistant

The Cat should **not** be:
- a fake person
- a constant pop-up interruption
- an auto-blogger
- an overconfident advice machine
- a substitute for your authorship

### Best framing
“Ask the Cat” is a guide to the archive and lessons.

Examples:
- “I’m struggling to trust my team. What should I read first?”
- “What does the site say about patience?”
- “Give me a 3-piece reading path for leading through uncertainty.”
- “Summarize this article in plain English.”
- “What leadership lesson fits conflict, repair, and boundaries?”

### Best UX placement
- launcher in lower right
- subtle invite module on homepage
- inline prompt box on article pages
- post-reading prompt after 60% scroll
- dedicated `/field-guide/` page later if desired

### Best constraints
The Cat must:
- answer from your content first
- cite related posts in every answer
- keep answers concise
- admit uncertainty
- never invent farm stories
- never fabricate offers or policies
- hand off to signup / resources naturally

### Strong conversion behavior
Good:
- “I found three essays on that. Want the reading path emailed to you?”
- “There is a free playbook on this topic.”
- “This question is covered more deeply in Steward’s Circle.”

Bad:
- “Buy now!!!”
- “You need coaching immediately.”
- “Here are 12 affiliate products.”

---

## 23. Cheshire Cat sidecar architecture

Recommended architecture:

### Layer 1: Ghost
- source of truth for published content
- pages, posts, tags, member flows, newsletters

### Layer 2: Sync service
- listens for Ghost webhooks
- fetches fresh published content from Ghost Content API
- writes normalized corpus files
- optionally posts updates to Cat ingestion endpoint

### Layer 3: Cheshire Cat
- separate service / container
- ingests site corpus
- runs chat and retrieval
- exposes HTTP or websocket endpoint

### Layer 4: Theme widget
- lazy-load front-end chat widget
- launches only after user intent
- passes current URL / title for context

### Event flow
1. New Ghost post published
2. Ghost webhook hits sync service
3. Sync service fetches latest posts from Content API
4. Corpus files update
5. Cheshire Cat re-ingests or receives sync payload
6. Widget can now cite the new content

### Why this is better than baking AI directly into Ghost
- clean separation of concerns
- easier to disable
- easier to replace later
- lower risk to theme performance
- easier compliance and monitoring

---

## 24. Sidecar rules for live content

You asked for live content in the blog. This needs guardrails.

### Safe version of live content
The Cat can generate:
- contextual summaries
- reading paths
- “lesson of the day” snippets from approved posts
- related post recommendations
- glossary-style explanations
- draft outlines stored outside public view
- draft micro-posts saved as Ghost drafts for review

### Unsafe version
Do not allow:
- automated public post publishing
- autonomous SEO pages
- unsupervised quote generation
- public answers that look like expert advice without source grounding

### Best compromise
Use the Cat to create:
- **drafts**
- **assistant boxes**
- **contextual side panels**
- **member-only interactive Q&A**
- **emailable reading paths**

Human review should be required before public publishing.

---

## 25. Metrics that matter

### Awareness
- total subscribers
- new subscribers per week
- top landing pages
- top referral sources
- podcast / partnership conversions

### Engagement
- newsletter open and click rates
- read depth on flagship posts
- repeat visitor rate
- sidecar usage rate
- sidecar to signup conversion

### Revenue
- free-to-paid conversion
- playbook sales
- MRR from membership
- average revenue per subscriber
- revenue by source

### Quality indicators
- direct replies to emails
- recommendation rate
- organic backlinks
- time on flagship essays
- percentage of posts with meaningful comments / replies
- invitations to speak / collaborate

---

## 26. Editorial voice rules

Codify this so Codex and future collaborators do not drift.

### Voice characteristics
- grounded
- observant
- direct
- practical
- humane
- a little lyrical
- never inflated

### Avoid
- TED-talk clichés
- fake profundity
- excessive alliteration
- corporate buzzwords
- political signaling unless necessary
- sentimental farm cosplay
- sermonizing

### Good sentence pattern
Observation → lesson → practical implication

Example:
“On the farm, neglect usually announces itself late. Leadership is similar. By the time something breaks loudly, it has often been asking quietly for weeks.”

---

## 27. Home page conversion copy ideas

### Hero options

#### Hero A
**What the farm teaches about leadership.**  
Field-tested lessons on stewardship, trust, timing, and building what lasts.

#### Hero B
**Leadership looks different when weather gets a vote.**  
Learn practical leadership from the daily realities of farming.

#### Hero C
**Less jargon. More seasons. Better leadership.**  
A weekly note on leading people, making decisions, and caring for what’s entrusted to you.

### Newsletter CTA options
- Get the weekly Field Notes
- Join the newsletter from the field
- Receive one grounded leadership lesson each week
- Start reading from the field

---

## 28. Flagship article ideas

These should be some of the first and best pieces on the site.

1. **What the farm teaches about leadership**
2. **Trust is built like a fence, one post at a time**
3. **Why good leaders fix small things early**
4. **The difference between stewardship and ego**
5. **How to lead through weather you cannot control**
6. **Patience is not passivity**
7. **What harvest season teaches about accountability**
8. **Boundaries are a form of care**
9. **Maintenance is leadership**
10. **Why timing matters more than intensity**

---

## 29. Launch checklist

### Brand
- domain connected
- logo wordmark set
- tagline chosen
- color system chosen
- typography chosen

### Ghost
- production install working
- email configured
- Stripe connected
- Portal customized
- navigation configured
- analytics enabled
- member sources enabled
- custom integration created
- webhook created

### Content
- 10 to 15 strong posts
- 1 lead magnet
- about page
- start here page
- privacy and disclosures
- welcome sequence
- homepage curated

### SEO / technical
- Search Console
- sitemap submitted
- analytics reviewed
- structured data validated
- social previews set
- page speed checked
- accessibility pass completed

### Sidecar
- Cat endpoint working
- sync job working
- answers grounded in content
- widget lazy-loaded
- sidecar analytics tracked
- escalation behavior tested

---

## 30. Codex operating plan

Codex works best when given phased, testable work with clear acceptance criteria.

## Phase 1: Foundation
Tasks:
- scaffold custom theme
- configure routes
- create reusable partials
- set custom settings
- verify Ghost theme passes validation

Acceptance:
- theme uploads successfully
- homepage renders
- archives render
- post pages render
- navigation works

## Phase 2: Homepage experience
Tasks:
- hero
- pillars
- featured posts
- newsletter CTA
- story strip
- sidecar launcher
- mobile styling

Acceptance:
- homepage feels complete on desktop and mobile
- all major sections editable via Ghost or theme settings

## Phase 3: Content architecture
Tasks:
- topic hubs
- playbooks archive
- start here page template
- internal linking helpers
- reading path modules

Acceptance:
- editors can publish content into the right zone without code changes

## Phase 4: Membership conversion
Tasks:
- portal styling
- premium blocks
- membership page
- free-to-paid CTA system
- newsletter landing page

Acceptance:
- clear value ladder
- frictionless signup flow

## Phase 5: Sidecar integration
Tasks:
- widget load
- API adapter
- page context handoff
- sync service
- webhook listener
- analytics events

Acceptance:
- Cat can answer from current content
- Cat links back to posts
- Cat does not hurt performance on first load

## Phase 6: Optimization
Tasks:
- structured data
- performance pass
- accessibility pass
- metadata review
- launch QA

Acceptance:
- Lighthouse and manual QA are within target thresholds

---

## 31. Acceptance criteria for the finished site

A finished site should satisfy all of these:

### Brand
- instantly clear what the site is
- looks distinctive, not template-generic
- feels human and trustworthy

### UX
- homepage tells a story
- navigation is obvious
- first-time visitors know where to start
- content is easy to browse by topic and format

### Content
- flagship posts exist
- field notes rhythm exists
- playbooks exist
- email flow exists

### Business
- signup is prominent
- paid offer is credible
- at least one digital product can be sold
- analytics and attribution are working

### AI sidecar
- sidecar is helpful, not intrusive
- answers are grounded in site content
- links to source posts are included
- does not auto-publish public content

### Technical
- fast
- accessible
- valid theme
- clean structured data
- resilient routes

---

## 32. Paste-ready Codex briefing philosophy

When you hand this to Codex, be explicit:

- break work into phases
- show diffs
- run validations
- keep changes minimal and reversible
- prefer lightweight vanilla JS over heavy dependencies
- preserve Ghost compatibility
- document any assumptions
- ask Codex to propose a plan before major file edits
- ask Codex to implement tests or verification steps where possible

---

## 33. Final recommendation

Build FarmLeadership.com as a **modern field guide for grounded leadership**.

Do not chase empty scale.
Do not imitate shiny creator brands.
Do not let the AI cat become the author.

Let the farm stay the teacher.
Let Ghost handle publishing, memberships, newsletters, and growth.
Let the Cat guide, summarize, and personalize discovery.
Let your own voice remain the reason people return.

That combination can become:
- memorable
- ethical
- differentiated
- monetizable
- durable

And durable is the whole point.

---

## 34. Research notes and source map

These references shaped the technical and white-hat recommendations in this document:

### Ghost
- Ghost home: https://ghost.org/
- Themes structure: https://docs.ghost.org/themes/structure
- Routing: https://docs.ghost.org/themes/routing
- Custom settings: https://docs.ghost.org/themes/custom-settings
- Search: https://docs.ghost.org/themes/search
- Members: https://docs.ghost.org/members
- Newsletters: https://docs.ghost.org/newsletters
- Portal customization: https://ghost.org/help/customize-portal/
- Recommendations: https://ghost.org/help/recommendations/
- Member sources: https://ghost.org/help/member-sources/
- Native analytics: https://ghost.org/help/native-analytics/
- Code injection: https://ghost.org/tutorials/use-code-injection-in-ghost/
- Content API: https://docs.ghost.org/content-api
- Admin API: https://docs.ghost.org/admin-api
- Webhooks: https://docs.ghost.org/webhooks
- Install on Ubuntu: https://docs.ghost.org/install/ubuntu
- Install with Docker: https://docs.ghost.org/install/docker
- Stripe integration: https://ghost.org/integrations/stripe/

### Search / web standards
- Google Search Essentials: https://developers.google.com/search/docs/essentials
- Google spam policies: https://developers.google.com/search/docs/essentials/spam-policies
- Google SEO Starter Guide: https://developers.google.com/search/docs/fundamentals/seo-starter-guide
- Article structured data: https://developers.google.com/search/docs/appearance/structured-data/article
- FAQ structured data: https://developers.google.com/search/docs/appearance/structured-data/faqpage
- Core Web Vitals: https://developers.google.com/search/docs/appearance/core-web-vitals
- WCAG 2.2: https://www.w3.org/TR/WCAG22/

### Monetization / disclosures
- FTC endorsement guidance: https://www.ftc.gov/business-guidance/resources/ftcs-endorsement-guides-what-people-are-asking
- FTC endorsements overview: https://www.ftc.gov/news-events/topics/truth-advertising/advertisement-endorsements

### Cheshire Cat
- Cheshire Cat home: https://cheshirecat.ai/
- Cheshire Cat docs: https://cheshire-cat-ai.github.io/docs/
- Cheshire Cat getting started: https://cheshirecat.ai/hello-world/

### Codex
- Codex docs: https://developers.openai.com/codex/
- Codex prompting: https://developers.openai.com/codex/prompting/
- Codex prompting guide: https://developers.openai.com/cookbook/examples/gpt-5/codex_prompting_guide
- Codex skills: https://developers.openai.com/codex/skills/
