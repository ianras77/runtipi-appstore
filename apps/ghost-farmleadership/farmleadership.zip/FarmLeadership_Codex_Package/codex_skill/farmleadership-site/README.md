# FarmLeadership Codex skill

Place this folder where your Codex installation loads local skills if you want a reusable FarmLeadership-specific workflow.

The main instructions live in `SKILL.md`.
