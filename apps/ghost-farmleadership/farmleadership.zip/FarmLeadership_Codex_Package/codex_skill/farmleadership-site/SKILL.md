---
name: farmleadership-site
description: Use this skill when building or modifying the FarmLeadership.com Ghost theme, routing, homepage, membership flow, content architecture, or Cheshire Cat sidecar integration. Do not use it for unrelated repos.
---

# FarmLeadership Site Skill

## Mission

Build and refine FarmLeadership.com as a Ghost-based content business about what farming teaches leadership.

The site should feel:
- grounded
- editorial
- modern
- memorable
- human
- practical

The site should not feel:
- generic
- over-automated
- corporate
- hypey
- cluttered

## Source files to read first

- `README.md`
- `farmleadership_codex_program.md`
- `codex_master_prompt.md`

## Product principles

1. Keep the author voice central.
2. Use Ghost-native features where possible.
3. Prefer lightweight implementation.
4. Keep the site fast and accessible.
5. Use AI as a guide and assistant, not as an autonomous publisher.
6. Break work into phases and verify after each phase.

## Implementation preferences

- Ghost custom homepage on `/`
- archives for field notes and playbooks
- topic hubs via channels or collections
- reusable partials
- vanilla JS
- custom theme settings in `package.json`
- sidecar lazy loading

## Never do these

- introduce heavy SPA frameworks
- auto-publish AI-generated posts
- create scaled thin SEO pages
- add dark patterns
- add aggressive popups on first paint
- ship inaccessible components knowingly

## Required checks after edits

After relevant changes:
- inspect templates for Ghost compatibility
- confirm required helpers still exist in `default.hbs`
- ensure CSS changes do not break mobile layout
- ensure JS is deferred or lazy where possible
- summarize changed files and how to test them

## UX copy style

Prefer:
- “Get the weekly Field Notes”
- “Start here”
- “Ask the Cat”
- “Today’s field lesson”

Avoid:
- “10x”
- “unlock”
- “dominate”
- “crush”

## Cheshire Cat guidance

The sidecar is a reading guide and archive navigator.

It should:
- help visitors find relevant content
- provide reading paths
- summarize published posts
- support conversion gently

It should not:
- invent stories
- over-promise
- replace authorship
- auto-generate public content at scale
