# How to merge the overlays into your existing site

## Grav

Copy:

- `overlays/grav/user/themes/zoroasteria/` -> `your-grav-site/user/themes/zoroasteria/`
- `overlays/grav/user/plugins/zoroasteriaoracle/` -> `your-grav-site/user/plugins/zoroasteriaoracle/`
- `overlays/grav/user/pages/01.home/oracle.md` -> adapt into your home page folder

Then set the home page template to `oracle` or copy parts of the template into your existing home template.

## Cheshire Cat

Copy:

- `overlays/cheshire/plugins/zoroasteria_cat/` -> `your-cheshire/plugins/zoroasteria_cat/`

Then activate the plugin in the Cat admin panel.

## Shared state

Mount or copy:

- `runtime/oracle/oracle-state.json` -> `your-grav-site/user/data/zoroasteria/oracle-state.json`
