# Source curation strategy

## Principle

The site can be alive without becoming careless.

## Three content lanes

### 1. Source
Primary texts, real quotations, and scholarly excerpts with provenance.

### 2. Commentary
Human-written interpretation, editorial notes, contextual essays.

### 3. Oracle
Generated fragments, recompositions, meditations, invitations, and live dialogue.

## Ingestion approach

Curate a small, trustworthy seed corpus first.

Suggested categories:

- primary texts
- scholarly introductions
- timelines
- thematic notes
- glossary entries

## Metadata to preserve

For each source item, keep as much of the following as possible:

- title
- author / translator
- tradition / corpus
- url or citation note
- date or period
- tags
- confidence in provenance

## Rendering rule

Whenever a visitor reads a text fragment on the site, they should be able to tell whether it came from:

- a source
- a human commentator
- the oracle

That distinction should be obvious in both markup and design.
