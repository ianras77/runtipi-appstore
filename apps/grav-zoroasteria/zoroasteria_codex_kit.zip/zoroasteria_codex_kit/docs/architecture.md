# Architecture

## Guiding idea

Do not let the LLM directly own the whole website.

That path creates chaos, invisible regressions, and a site that mutates faster than anyone can curate.

Instead:

- **Grav** holds the visible structure
- **Cheshire Cat** holds the living intelligence
- **Gateway** translates between the two
- **Shared state** gives the front page a stable, inspectable contract

## Component map

### Grav
Responsibilities:

- routes
- templates
- media
- page editing
- publishing
- SEO-friendly rendering
- stable first paint

### Cheshire Cat
Responsibilities:

- house voice
- retrieval over curated source material
- interactive dialogue
- structured fragment generation
- dynamic response behavior

### Gateway
Responsibilities:

- talk privately to Cheshire Cat over WebSocket
- keep tokens off the browser
- generate and write `oracle-state.json`
- serve chat and state endpoints to the site
- degrade gracefully when Cat is unavailable

### Shared state file
Responsibilities:

- make dynamic content renderable by Grav
- keep the front page fast
- allow inspection and fallback behavior
- support periodic refresh without rebuilding the whole site

## Why this is the right shape

If Grav calls the LLM directly during page render, your page latency, reliability, and cost become difficult to control.

If the browser talks directly to Cheshire Cat, you risk exposing tokens and creating a brittle client.

If the LLM rewrites full pages constantly, editorial trust collapses.

This architecture keeps the magic, but puts walls around the furnace.

## Phase 1 contract

The home page only depends on:

- `runtime/oracle/oracle-state.json`
- site theme templates
- gateway chat endpoint for live conversation

That means the core experience still has shape, even if live generation stalls.

## Phase 2 expansion paths

Later, you can add:

- room-specific state files
- visitor-scoped memory trails
- citation explorers
- authenticated notebooks
- richer TTS and audio ambience
- event-driven refresh jobs
