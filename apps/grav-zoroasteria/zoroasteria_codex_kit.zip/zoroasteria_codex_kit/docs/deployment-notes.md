# Deployment notes

## Production shape

A safe production shape is:

- public traffic -> Caddy
- Caddy -> Grav and gateway
- gateway -> Cheshire Cat over private Docker network
- Cheshire Cat admin kept private
- Qdrant private
- shared `runtime/oracle/` mounted read-write for gateway and read-only / user-data for Grav

## Why not direct browser -> Cheshire Cat?

Because the browser should not hold long-lived Cat credentials.

## Sensible first deployment

Get the local Docker lab working first.  
Then transplant the same shape to your server.

## Keep private

- Cheshire Cat admin
- Qdrant
- raw gateway environment files
