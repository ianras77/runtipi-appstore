# AGENTS.md

## Project overview

This repository builds a living Grav website for `zoroasteria.com`.

Architecture:

- `overlays/grav/` contains the Grav theme and plugin overlay
- `overlays/cheshire/` contains the Cheshire Cat plugin overlay
- `services/gateway/` contains the secure bridge service
- `runtime/oracle/` contains dynamic state written by the gateway
- `deployment/` contains the Docker lab and reverse proxy setup
- `docs/` contains editorial and architectural decisions
- `Prompt.md` is the canonical product specification

## Non-negotiable rules

- Do not expose Cheshire Cat secrets to browser code.
- Do not present generated text as canonical scripture.
- Keep Grav as the stable rendering and publishing layer.
- Keep Cheshire Cat as the conversational and generative layer.
- Prefer incremental, testable changes over sprawling rewrites.
- Preserve human editorial override everywhere possible.

## Mandatory skill usage

- Use `$implementation-strategy` before architecture work, file moves, or multi-service edits.
- Use `$design-direction` before significant frontend styling or layout changes.
- Use `$content-guardrails` before changing prompts, copy systems, or source ingestion.
- Use `$code-change-verification` before declaring the work complete.

## Coding rules

### Grav
- Favor Twig templates and small plugins over brittle hacks.
- Use a plugin to surface computed data into Twig.
- Keep the theme expressive but readable.
- Preserve server-rendered HTML first, then layer on client-side enrichment.

### Gateway
- Keep routes small and explicit.
- Handle Cheshire Cat outages gracefully.
- Use typed request and response models.
- Keep file writes deterministic.

### Cheshire Cat
- Put persona logic in hooks.
- Put reusable structured generation in tools.
- Keep prompt outputs parseable when the site depends on them.
- Tag ingested documents with metadata whenever possible.

## Editorial rules

- Canonical material must stay distinguishable from generated material.
- Generated fragments should sound alive, but not fraudulent.
- Do not mimic translation authority unless a real source is shown.
- Prefer clear provenance fields in JSON structures.

## Visual direction

- Build atmosphere through depth, contrast, motion, and typography.
- Avoid generic SaaS shells.
- Avoid default component-library sameness.
- Let the interface feel like a chamber, not a dashboard.

## Build and verification commands

### Python
- `python -m py_compile services/gateway/app/*.py`

### Quick file checks
- validate JSON files after edits
- validate YAML files after edits

### Manual checks
- load home page
- verify oracle fragments render
- send a chat message
- toggle voice output
- run refresh and confirm `runtime/oracle/oracle-state.json` changes
- verify the site still loads if Cheshire Cat is unavailable

## When in doubt

Read, in order:

1. `Prompt.md`
2. `docs/architecture.md`
3. `docs/persona.md`
4. `docs/source-curation.md`
