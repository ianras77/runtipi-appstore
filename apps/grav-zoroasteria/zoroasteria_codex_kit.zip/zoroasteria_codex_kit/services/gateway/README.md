# Gateway service

This FastAPI service keeps browser traffic simple and keeps Cheshire Cat credentials off the client.

## Endpoints

- `GET /health`
- `GET /site-state`
- `POST /refresh`
- `POST /chat`

## Notes

- The gateway talks to Cheshire Cat over WebSocket.
- The gateway writes `oracle-state.json` into `/app/runtime`.
- Grav reads that file through the shared volume mount.
- If Cheshire Cat fails, the gateway falls back to the last known state or a starter state.
