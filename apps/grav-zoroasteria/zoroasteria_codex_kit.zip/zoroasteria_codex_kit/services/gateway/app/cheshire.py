from __future__ import annotations

import json
import os
from dataclasses import dataclass
from urllib.parse import quote

from websockets.asyncio.client import connect


@dataclass
class CheshireConfig:
    ws_url: str
    token: str | None = None


def get_config() -> CheshireConfig:
    return CheshireConfig(
        ws_url=os.getenv("CHESHIRE_CAT_WS_URL", "ws://cat/ws"),
        token=os.getenv("CCAT_WS_TOKEN") or None,
    )


def build_ws_url(user_id: str) -> str:
    cfg = get_config()
    base = cfg.ws_url.rstrip("/")
    encoded_user = quote(user_id)
    url = f"{base}/{encoded_user}"
    if cfg.token:
        url = f"{url}?token={quote(cfg.token)}"
    return url


async def ask_cat(prompt: str, user_id: str = "visitor") -> str:
    """
    Send a single prompt to Cheshire Cat over WebSocket and return the final chat content.

    The Cheshire Cat docs show a simple interaction pattern:
    connect -> send {"text": "..."} -> read messages until type == "chat".
    This helper follows that pattern and falls back to token accumulation if needed.
    """
    url = build_ws_url(user_id)
    token_fragments: list[str] = []
    final_message = ""

    async with connect(url) as websocket:
        await websocket.send(json.dumps({"text": prompt}))

        async for raw_message in websocket:
            data = json.loads(raw_message)
            msg_type = data.get("type")
            content = data.get("content", "")

            if msg_type == "chat":
                final_message = content
                break

            # Some deployments stream incremental content. Keep a light fallback.
            if content and isinstance(content, str):
                token_fragments.append(content)

    return final_message or "".join(token_fragments)
