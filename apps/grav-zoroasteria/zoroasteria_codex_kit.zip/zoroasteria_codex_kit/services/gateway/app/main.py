from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .cheshire import ask_cat

app = FastAPI(title="Zoroasteria Gateway", version="0.1.0")


class ChatRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    page: str = "/"
    visitor_id: str = "visitor"


class ChatResponse(BaseModel):
    message: str
    mode: str = "oracle"
    spoken_text: str | None = None


class RefreshRequest(BaseModel):
    theme: str | None = None


def state_path() -> Path:
    configured = os.getenv("ORACLE_STATE_PATH", "/app/runtime/oracle-state.json")
    path = Path(configured)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def fallback_state(theme: str | None = None) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    living_theme = (theme or os.getenv("ORACLE_THEME", "fire and memory")).strip()
    return {
        "updated_at": now,
        "theme": living_theme,
        "headline": "A flame that remembers",
        "subhead": "Ancient wisdom, living questions, and a voice that keeps moving.",
        "whisper": "Do not ask only what the fire means. Ask what it is revealing about your attention.",
        "ritual": {
            "title": "Small ritual",
            "prompt": "Name one thing you are feeding today: clarity, courage, vanity, fear, patience, or love."
        },
        "fragments": [
            {
                "mode": "oracle",
                "title": "Threshold",
                "text": "The oldest teachings often begin with a choice, not a spectacle.",
                "source_label": "Generated oracle fragment"
            },
            {
                "mode": "oracle",
                "title": "Ember",
                "text": "What survives in you after noise leaves is nearer to wisdom than whatever shouts the loudest.",
                "source_label": "Generated oracle fragment"
            },
            {
                "mode": "commentary",
                "title": "Editorial note",
                "text": "This site separates source, commentary, and oracle so beauty never has to borrow authority.",
                "source_label": "House note"
            }
        ],
        "constellations": ["fire", "choice", "memory", "truth", "return"],
    }


def extract_json_block(raw: str) -> dict[str, Any] | None:
    raw = raw.strip()
    if raw.startswith("{") and raw.endswith("}"):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None

    start = raw.find("{")
    end = raw.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return None

    candidate = raw[start:end + 1]
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        return None


def save_state(data: dict[str, Any]) -> None:
    path = state_path()
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def load_state() -> dict[str, Any]:
    path = state_path()
    if not path.exists():
        data = fallback_state()
        save_state(data)
        return data

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        data = fallback_state()
        save_state(data)
        return data


async def generate_state(theme: str | None = None) -> dict[str, Any]:
    living_theme = (theme or os.getenv("ORACLE_THEME", "fire and memory")).strip()

    prompt = f"""
You are generating the dynamic front-page state for a website called Zoroasteria.

Return ONLY strict JSON with this shape:
{{
  "updated_at": "ISO-8601 string",
  "theme": "string",
  "headline": "short striking title",
  "subhead": "single sentence",
  "whisper": "single evocative sentence",
  "ritual": {{
    "title": "short title",
    "prompt": "brief invitation or ritual question"
  }},
  "fragments": [
    {{
      "mode": "source|commentary|oracle",
      "title": "short title",
      "text": "1-2 sentences",
      "source_label": "provenance label"
    }},
    {{
      "mode": "source|commentary|oracle",
      "title": "short title",
      "text": "1-2 sentences",
      "source_label": "provenance label"
    }},
    {{
      "mode": "source|commentary|oracle",
      "title": "short title",
      "text": "1-2 sentences",
      "source_label": "provenance label"
    }}
  ],
  "constellations": ["5 short words or phrases"]
}}

Rules:
- The theme is: "{living_theme}".
- Generated material must be labeled honestly.
- Never fabricate a direct ancient quotation.
- Make the language luminous but controlled.
- Do not include markdown fences.
""".strip()

    try:
        raw = await ask_cat(prompt, user_id="site_state")
        data = extract_json_block(raw)
        if not data:
            raise ValueError("Cheshire Cat response did not contain valid JSON.")
        return data
    except Exception:
        return fallback_state(living_theme)


async def refresh_loop() -> None:
    minutes = int(os.getenv("AUTO_REFRESH_MINUTES", "0") or "0")
    if minutes <= 0:
        return

    while True:
        data = await generate_state()
        save_state(data)
        await asyncio.sleep(minutes * 60)


@app.on_event("startup")
async def startup() -> None:
    save_state(load_state())
    minutes = int(os.getenv("AUTO_REFRESH_MINUTES", "0") or "0")
    if minutes > 0:
        asyncio.create_task(refresh_loop())


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/site-state")
async def get_site_state() -> dict[str, Any]:
    return load_state()


@app.post("/refresh")
async def refresh(request: RefreshRequest) -> dict[str, Any]:
    data = await generate_state(request.theme)
    save_state(data)
    return data


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest) -> ChatResponse:
    prompt = f"""
You are the living oracle of Zoroasteria.

Context:
- current page: {request.page}
- visitor id: {request.visitor_id}

User message:
{request.text}

Rules:
- reply in 1 to 4 short paragraphs
- be lucid, warm, and exact
- do not pretend generated text is canonical scripture
- if you reference source material, state that it is commentary or interpretation unless you are certain
""".strip()

    try:
        message = await ask_cat(prompt, user_id=request.visitor_id)
        message = message.strip()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gateway could not reach Cheshire Cat: {exc}") from exc

    if not message:
        raise HTTPException(status_code=502, detail="Cheshire Cat returned an empty response.")

    return ChatResponse(
        message=message,
        spoken_text=message,
    )
