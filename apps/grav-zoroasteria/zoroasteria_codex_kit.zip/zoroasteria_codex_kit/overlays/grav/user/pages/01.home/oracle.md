---
title: Zoroasteria
template: oracle
cache_enable: false
process:
  twig: true
description: A living temple of ancient wisdom.
---

The threshold is open.
