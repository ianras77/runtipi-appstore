(() => {
  const stateScript = document.querySelector('#oracle-state');
  const rootConfig = window.ZOROASTERIA || { gatewayBase: '/api' };
  const gatewayBase = rootConfig.gatewayBase || '/api';

  const chatLog = document.querySelector('[data-chat-log]');
  const chatForm = document.querySelector('[data-chat-form]');
  const refreshButton = document.querySelector('[data-refresh-state]');
  const voiceToggle = document.querySelector('[data-voice-toggle]');

  let voiceEnabled = false;

  function getVisitorId() {
    const key = 'zoroasteria-visitor-id';
    let value = localStorage.getItem(key);
    if (!value) {
      value = `visitor-${Math.random().toString(36).slice(2, 10)}`;
      localStorage.setItem(key, value);
    }
    return value;
  }

  function parseInitialState() {
    if (!stateScript) return null;
    try {
      return JSON.parse(stateScript.textContent || '{}');
    } catch {
      return null;
    }
  }

  function appendChatEntry(role, text) {
    if (!chatLog) return;
    const article = document.createElement('article');
    article.className = `chat-entry chat-entry-${role}`;
    article.innerHTML = `
      <span class="chat-role">${role === 'human' ? 'You' : 'Oracle'}</span>
      <p></p>
    `;
    article.querySelector('p').textContent = text;
    chatLog.appendChild(article);
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  function speak(text) {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.96;
    utterance.pitch = 0.92;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  function renderState(state) {
    if (!state || typeof state !== 'object') return;

    const fieldMap = [
      ['headline', state.headline],
      ['subhead', state.subhead],
      ['whisper', state.whisper],
      ['ritual.title', state.ritual?.title],
      ['ritual.prompt', state.ritual?.prompt]
    ];

    for (const [key, value] of fieldMap) {
      const target = document.querySelector(`[data-field="${key}"]`);
      if (target && value) target.textContent = value;
    }

    const constellationList = document.querySelector('[data-list="constellations"]');
    if (constellationList && Array.isArray(state.constellations)) {
      constellationList.innerHTML = state.constellations
        .map(item => `<span class="constellation-pill">${escapeHtml(item)}</span>`)
        .join('');
    }

    const fragmentsGrid = document.querySelector('[data-list="fragments"]');
    if (fragmentsGrid && Array.isArray(state.fragments)) {
      fragmentsGrid.innerHTML = state.fragments.map(fragment => `
        <article class="fragment-card fragment-${escapeHtml(fragment.mode || 'oracle')}">
          <span class="mode-pill">${escapeHtml(fragment.mode || 'oracle')}</span>
          <h3>${escapeHtml(fragment.title || 'Untitled')}</h3>
          <p>${escapeHtml(fragment.text || '')}</p>
          <footer>${escapeHtml(fragment.source_label || '')}</footer>
        </article>
      `).join('');
    }
  }

  function escapeHtml(input) {
    return String(input)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  async function refreshState() {
    const response = await fetch(`${gatewayBase}/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });

    if (!response.ok) {
      throw new Error(`Refresh failed with ${response.status}`);
    }

    const data = await response.json();
    renderState(data);
  }

  async function sendChat(text) {
    const response = await fetch(`${gatewayBase}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        page: window.location.pathname,
        visitor_id: getVisitorId()
      })
    });

    if (!response.ok) {
      throw new Error(`Chat failed with ${response.status}`);
    }

    return response.json();
  }

  const initialState = parseInitialState();
  if (initialState) renderState(initialState);

  if (voiceToggle) {
    voiceToggle.addEventListener('click', () => {
      voiceEnabled = !voiceEnabled;
      voiceToggle.textContent = voiceEnabled ? 'Voice on' : 'Voice off';
      voiceToggle.setAttribute('aria-pressed', String(voiceEnabled));
      if (!voiceEnabled && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    });
  }

  if (refreshButton) {
    refreshButton.addEventListener('click', async () => {
      refreshButton.disabled = true;
      const original = refreshButton.textContent;
      refreshButton.textContent = 'Shifting…';
      try {
        await refreshState();
      } catch (error) {
        appendChatEntry('oracle', `The sky did not shift cleanly. ${error.message}`);
      } finally {
        refreshButton.disabled = false;
        refreshButton.textContent = original;
      }
    });
  }

  if (chatForm) {
    chatForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const textarea = chatForm.querySelector('textarea[name="text"]');
      if (!textarea) return;
      const text = textarea.value.trim();
      if (!text) return;

      appendChatEntry('human', text);
      textarea.value = '';

      try {
        const data = await sendChat(text);
        appendChatEntry('oracle', data.message);
        if (data.spoken_text) speak(data.spoken_text);
      } catch (error) {
        appendChatEntry('oracle', `The oracle is veiled right now. ${error.message}`);
      }
    });
  }
})();
