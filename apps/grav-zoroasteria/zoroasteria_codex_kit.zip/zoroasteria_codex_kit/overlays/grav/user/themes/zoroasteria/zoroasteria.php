<?php

namespace Grav\Theme;

use Grav\Common\Theme;

/**
 * Theme bootstrap. Adds theme assets.
 */
class Zoroasteria extends Theme
{
    public static function getSubscribedEvents(): array
    {
        return [
            'onTwigSiteVariables' => ['onTwigSiteVariables', 0],
        ];
    }

    public function onTwigSiteVariables(): void
    {
        $this->grav['assets']
            ->addCss('theme://css/zoroasteria.css');

        $this->grav['assets']
            ->addJs('theme://js/oracle.js', ['group' => 'bottom']);
    }
}
