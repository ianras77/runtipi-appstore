<?php

namespace Grav\Plugin;

use Grav\Common\Grav;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

/**
 * Minimal Twig bridge for reading the living oracle state.
 */
class ZoroasteriaOracleTwigExtension extends AbstractExtension
{
    private Grav $grav;

    public function __construct(Grav $grav)
    {
        $this->grav = $grav;
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('oracle_state', [$this, 'oracleState']),
        ];
    }

    /**
     * Read JSON state from user/data and return a safe PHP array.
     */
    public function oracleState(): array
    {
        $relativePath = (string) $this->grav['config']->get(
            'plugins.zoroasteriaoracle.site_state_relative_path',
            'data/zoroasteria/oracle-state.json'
        );

        $userPath = rtrim((string) $this->grav['locator']->findResource('user://', true, true), DIRECTORY_SEPARATOR);
        $absolutePath = $userPath . DIRECTORY_SEPARATOR . ltrim($relativePath, DIRECTORY_SEPARATOR);

        if (!is_file($absolutePath)) {
            return [
                'headline' => 'A fire waiting for breath',
                'subhead' => 'No live oracle state was found yet.',
                'whisper' => 'Refresh the gateway or seed the state file.',
                'fragments' => [],
                'constellations' => [],
                'ritual' => [
                    'title' => 'Begin',
                    'prompt' => 'Bring the first ember into being.',
                ],
            ];
        }

        $raw = file_get_contents($absolutePath);
        if ($raw === false) {
            return [];
        }

        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }
}
