<?php

namespace Grav\Plugin;

use Grav\Common\Plugin;

/**
 * Exposes dynamic oracle state to Twig templates.
 */
class ZoroasteriaoraclePlugin extends Plugin
{
    public static function getSubscribedEvents(): array
    {
        return [
            'onPluginsInitialized' => ['onPluginsInitialized', 0],
        ];
    }

    public function onPluginsInitialized(): void
    {
        if ($this->isAdmin()) {
            return;
        }

        $this->enable([
            'onTwigExtensions' => ['onTwigExtensions', 0],
            'onTwigSiteVariables' => ['onTwigSiteVariables', 0],
        ]);
    }

    public function onTwigExtensions(): void
    {
        require_once __DIR__ . '/twig/ZoroasteriaOracleTwigExtension.php';
        $this->grav['twig']->twig->addExtension(new ZoroasteriaOracleTwigExtension($this->grav));
    }

    public function onTwigSiteVariables(): void
    {
        $twig = $this->grav['twig'];
        $twig->twig_vars['oracle_settings'] = [
            'gateway_base' => $this->config->get('plugins.zoroasteriaoracle.gateway_base', '/api'),
        ];
    }
}
