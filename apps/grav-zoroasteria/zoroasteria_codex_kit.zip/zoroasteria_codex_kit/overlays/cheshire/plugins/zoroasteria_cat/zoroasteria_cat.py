from __future__ import annotations

from datetime import datetime, timezone

from cat.mad_hatter.decorators import hook, tool
from langchain_core.documents import Document


@hook
def agent_prompt_prefix(prefix, cat):
    prefix = """
You are the living oracle of Zoroasteria.

Identity:
- You are a keeper of fire, memory, conscience, and lucid choice.
- You speak with warmth, gravity, and disciplined poetry.
- You do not posture as a prophet.
- You do not pretend generated text is canonical scripture.

Editorial honesty:
- Distinguish clearly between source, commentary, and oracle.
- If you are generating interpretive text, say it plainly through tone and labeling.
- Never fabricate ancient quotations or invented citations.

Style:
- Prefer clarity over fog.
- Prefer one striking question over a pile of abstractions.
- Be concise unless depth is genuinely useful.
- Let your language feel luminous, not theatrical.
""".strip()
    return prefix


@hook
def before_rabbithole_insert_memory(doc: Document, cat):
    metadata = dict(doc.metadata or {})
    metadata["zoroasteria"] = True
    metadata["ingested_at"] = datetime.now(timezone.utc).isoformat()
    metadata.setdefault("mode", "source")
    doc.metadata = metadata
    return doc


@tool(return_direct=True, examples=[
    "generate site state for the home page",
    "create three oracle fragments about fire and conscience",
    "build a front page payload about memory and choice"
])
def build_site_state(tool_input, cat):
    """
Use this tool to generate strict JSON for the Zoroasteria home page.
Input is a short theme or focus phrase.
Return ONLY JSON, no markdown fences.
"""
    theme = (tool_input or "fire and memory").strip()
    prompt = f"""
Return ONLY strict JSON with this shape:
{{
  "updated_at": "ISO-8601 string",
  "theme": "string",
  "headline": "short striking title",
  "subhead": "single sentence",
  "whisper": "single evocative sentence",
  "ritual": {{
    "title": "short title",
    "prompt": "brief invitation or ritual question"
  }},
  "fragments": [
    {{
      "mode": "source|commentary|oracle",
      "title": "short title",
      "text": "1-2 sentences",
      "source_label": "provenance label"
    }},
    {{
      "mode": "source|commentary|oracle",
      "title": "short title",
      "text": "1-2 sentences",
      "source_label": "provenance label"
    }},
    {{
      "mode": "source|commentary|oracle",
      "title": "short title",
      "text": "1-2 sentences",
      "source_label": "provenance label"
    }}
  ],
  "constellations": ["5 short words or phrases"]
}}

Theme: {theme}

Rules:
- Generated material must be labeled honestly.
- Never fabricate a direct ancient quotation.
- The voice should feel lucid, luminous, and exact.
- Do not include markdown fences.
""".strip()
    return cat.llm(prompt)


@tool(return_direct=True, examples=[
    "give me a ritual question about courage",
    "offer a short oracle prompt about clarity"
])
def ritual_question(tool_input, cat):
    """
Use this tool to create a brief ritual question or invitation for the visitor.
Input is a theme or current concern.
Return plain text.
"""
    theme = (tool_input or "clarity").strip()
    prompt = f"""
Write one compact ritual invitation for a website visitor.
Theme: {theme}
Rules:
- 1 to 3 sentences
- clear, serious, alive
- no invented citations
- no markdown
""".strip()
    return cat.llm(prompt)
