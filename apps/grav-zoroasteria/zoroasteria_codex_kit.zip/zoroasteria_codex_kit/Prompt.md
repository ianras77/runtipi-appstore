# Zoroasteria project specification

Treat this file as the **authoritative product spec** for the project.  
Do not replace it with a simpler interpretation.

## Core ambition

Transform `zoroasteria.com` into a living digital temple of ancient wisdom.

The site must feel:

- uncanny
- luminous
- literary
- ceremonial
- dynamic
- deeply intentional

It must **not** feel like:

- a generic startup landing page
- a chatbot pasted onto a template
- an “AI generated content farm”
- a museum exhibit with no pulse

## Product concept

Use:

- **Grav** as the front-end CMS and publishing structure
- **Cheshire Cat** as the sidecar intelligence layer
- **Gateway service** as the secure bridge between the site and the Cat
- **Shared state JSON** as the simplest first dynamic rendering contract

The relationship is:

- Grav stores pages, media, structure, and editorial control
- Cheshire Cat holds the voice, retrieval, memory, and generative response layer
- Gateway prevents secret leakage and coordinates live content refreshes
- The front page renders stable HTML first, then enriches itself with live state

## Primary visitor experiences

### 1. Enter the temple
The landing page should feel like crossing a threshold, not opening a brochure.

### 2. Read living fragments
The visitor sees changing fragments, invocations, constellations, and ritual prompts.

### 3. Ask the oracle
The visitor can talk with the site and receive responses in the house voice.

### 4. Distinguish source from oracle
Canonical material, commentary, and generated text must remain visually and semantically distinct.

### 5. Hear the voice
The site should be capable of speaking replies out loud.  
For the first build, browser speech synthesis is acceptable.  
The architecture should make it easy to swap in richer TTS later.

## Deliverables

### Grav
- custom theme named `zoroasteria`
- custom plugin to expose `oracle_state()` to Twig
- home page template that reads dynamic state
- responsive design
- no-browser-secret policy
- clear metadata and semantic structure

### Cheshire Cat
- custom plugin named `zoroasteria_cat`
- house persona through hooks
- content guardrails
- helpers / tools for site fragment generation
- memory tagging for curated sources

### Gateway
- FastAPI service
- `/health`
- `/site-state`
- `/refresh`
- `/chat`
- private websocket communication to Cheshire Cat
- shared JSON output for Grav

### Deployment
- local Docker lab with:
  - Grav
  - Cheshire Cat
  - Qdrant
  - gateway
  - Caddy reverse proxy

### Content system
- starter JSON state schema
- curated source strategy
- labels for source/commentary/oracle

## Design constraints

The interface must feel authored and surprising.

Required design traits:

- asymmetry with discipline
- depth, glow, ash, ember, horizon, constellation motifs
- strong typography choices
- motion with meaning
- atmospheric backgrounds, not flat empty panels
- mobile-first readability without losing wonder

Forbidden traits:

- dashboard sameness
- default card-grid blandness
- purple-on-white AI cliché
- chrome-heavy UI noise
- overstuffed nav bars
- fake mysticism with no editorial backbone

## Content rules

Never invent or paraphrase ancient source material in a way that could be mistaken for direct quotation.

Every generated fragment should belong to one of these modes:

- `source`
- `commentary`
- `oracle`

When uncertain, prefer `oracle`.

## Security rules

- Do not expose Cheshire Cat API keys or websocket tokens to browsers.
- Browsers must talk to the gateway, not directly to the Cat.
- Keep Cheshire Cat admin private.
- Preserve the option to add JWT or site auth later.

## Phase 1 definition of done

Phase 1 is complete when:

1. the home page renders with beautiful custom styling
2. `oracle-state.json` is read by Grav and displayed in the page
3. the gateway can refresh that state by asking Cheshire Cat for structured content
4. the visitor can send a chat message and receive a reply
5. the visitor can optionally hear the reply spoken aloud
6. generated content is clearly labeled and visually distinct from source material
7. secrets remain server-side
8. the repository contains enough durable instructions for Codex to continue safely

## Phase 2 targets

After Phase 1 works, extend to:

- multiple oracle rooms / page archetypes
- chronology maps
- “embers” that drift between pages
- visitor memory trails
- source browsing with citations
- richer audio voice
- ambient sound and ritual transitions
- multilingual support if editorially justified
