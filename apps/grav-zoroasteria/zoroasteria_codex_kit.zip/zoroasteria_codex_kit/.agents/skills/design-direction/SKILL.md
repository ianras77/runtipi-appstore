---
name: design-direction
description: Use before visual or front-end changes. Keeps the site bold, ceremonial, responsive, and distinct from generic AI interfaces.
---

# Purpose

This project must not look interchangeable.

Use this skill before:

- layout redesign
- typography changes
- color system changes
- motion design changes
- component creation for the front page or oracle chat

# Visual language

Aim for:

- threshold, horizon, ember, smoke, mirror, constellation
- asymmetry with composure
- dramatic contrast without illegibility
- ritual feeling without kitsch
- literary tone rather than pseudo-magical clutter

Avoid:

- boxy dashboard grids
- bland cards everywhere
- default AI assistant chrome
- “mystic” clip art
- arbitrary motion

# Interaction notes

- Motion should imply atmosphere and transition.
- The page should feel alive even when no one is typing.
- Chat should feel integrated into the architecture, not bolted on.

# Accessibility floor

- Maintain readable text contrast.
- Respect reduced motion preferences.
- Keep interactive targets comfortably sized on mobile.
- Preserve semantic HTML and keyboard access.
