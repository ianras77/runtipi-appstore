---
name: code-change-verification
description: Use before marking work complete. Runs syntax checks, validates content files, and walks the manual oracle flow.
---

# Required checks

## Python
Run:

```bash
python -m py_compile services/gateway/app/*.py
```

## JSON / YAML
- Validate all changed JSON files.
- Validate all changed YAML files.

## Manual flow
Confirm:

1. home page loads
2. initial oracle state renders
3. refresh changes the shared state file
4. chat returns a response
5. voice toggle speaks or silently degrades
6. site still renders if the Cat is offline

# Reporting

In the final report:

- say what was verified
- say what was not verified
- distinguish syntax checks from runtime checks
- never imply a deployment was tested if it was not
