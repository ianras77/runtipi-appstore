---
name: implementation-strategy
description: Use before multi-file or multi-service changes. Produces a milestone plan, identifies risks, and freezes assumptions before code edits.
---

# Purpose

Use this skill before:

- changing architecture
- editing more than one service
- touching deployment and application code together
- adding or changing flows that affect Grav, gateway, and Cheshire Cat at once

# Workflow

1. Read `Prompt.md`.
2. Read relevant docs in `docs/`.
3. Identify the smallest viable milestone that advances the build.
4. Name:
   - target files
   - assumptions
   - dependencies
   - verification steps
5. Only then begin edits.

# Output format

Produce a compact plan with:

- objective
- files to change
- risks
- checks
- optional stretch items

# Specific repository concerns

Always check for these before implementation:

- Does this leak a secret to the client?
- Does this blur source vs oracle content?
- Does this make Grav depend on live LLM availability for first paint?
- Does this make the site harder for a human editor to control?
