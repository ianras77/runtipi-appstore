---
name: content-guardrails
description: Use before prompt changes, source ingestion, or generated copy changes. Protects provenance, honesty, and editorial trust.
---

# Purpose

This site deals with ancient wisdom. Trust matters more than flourish.

# Hard rules

- Never present generated text as direct scripture.
- Never fabricate a quotation and style it as canonical.
- If a passage is generated, label it as `oracle`.
- If a passage is editorial interpretation, label it as `commentary`.
- Reserve `source` for real cited material.

# House voice

The voice should feel:

- ancient without cosplay
- luminous without fogginess
- serious without stiffness
- poetic without purple overload
- intimate without false certainty

# Preferred metadata

Whenever structured content is generated, include:

- `mode`
- `title`
- `text`
- `source_label`
- `confidence` or `provenance_note` when appropriate

# Safe prompt pattern

When asking for structured content:

1. specify the allowed modes
2. ask for strict JSON
3. forbid invented citations
4. require generated material to be labeled
