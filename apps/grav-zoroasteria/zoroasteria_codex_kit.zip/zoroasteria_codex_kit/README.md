# Zoroasteria Codex Kit

This repository is a **Codex-ready build kit** for turning `zoroasteria.com` into a living Grav site with a Cheshire Cat sidecar.

The design idea is simple:

- **Grav is the temple**: stable pages, editing, structure, SEO, publishing.
- **Cheshire Cat is the oracle**: persona, dialogue, generative fragments, curated retrieval.
- **A tiny gateway service is the lantern**: it keeps secrets off the client, talks to the Cat over the private network, and writes a shared `oracle-state.json` file that Grav can render.

## What this kit contains

- `Prompt.md`: the authoritative project specification for Codex
- `AGENTS.md`: repository rules and operating instructions for Codex
- `.agents/skills/`: repo-local workflows for planning, design, verification, and content guardrails
- `docs/`: architecture, persona, and source curation notes
- `deployment/`: a Docker-first local lab with Grav, Cheshire Cat, Qdrant, gateway, and Caddy
- `overlays/`: files to merge into an existing Grav site and Cheshire Cat instance
- `services/gateway/`: a FastAPI sidecar that proxies the site to Cheshire Cat
- `runtime/oracle/oracle-state.json`: starter dynamic state for the front page

## Recommended build order

1. Read `Prompt.md`.
2. Read `AGENTS.md`.
3. Have Codex use `$implementation-strategy`.
4. Merge the Grav overlay into your Grav install.
5. Install the Cheshire Cat plugin from `overlays/cheshire/plugins/zoroasteria_cat`.
6. Run the Docker lab from `deployment/` or adapt it to your current server.
7. Use `$code-change-verification`.
8. Only after the core loop works, expand the content system and visual experiments.

## What “done” looks like

- A Grav home page renders from `oracle-state.json`.
- Visitors can speak with the oracle through the gateway.
- The page periodically refreshes generated fragments without exposing Cheshire Cat secrets to the browser.
- The site visually feels authored, strange, elegant, and alive.
- Canonical texts and generated interpretations are clearly distinguished.

## Important editorial rule

Generated text must **never** be presented as ancient scripture.  
The site should clearly label:

- **Source** for primary or scholarly material
- **Commentary** for human editorial interpretation
- **Oracle** for generated, living, speculative text

That distinction is a trust engine, not a footnote.
