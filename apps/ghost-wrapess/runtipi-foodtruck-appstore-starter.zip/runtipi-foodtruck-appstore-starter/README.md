# Food Truck Ideas RunTipi App Store Starter

This is a starter custom RunTipi app store for the Wrapess and SloppyHero project.

It is designed for a setup where:
- `wrapess.com` runs on its own Ghost app
- `sloppyhero.com` runs on its own Ghost app
- each site has its own Cheshire Cat instance
- a separate internal worker handles drafting and Ghost draft creation

## Included apps

- `wrapess-ghost`
- `sloppyhero-ghost`
- `wrapess-cat`
- `sloppyhero-cat`
- `foodtruck-content-ops`

## Notes

This scaffold is intentionally opinionated:
- Ghost apps are public and `force_expose: true`
- Cat apps are internal by default
- the content-ops app is internal and has `no_gui: true`
- all content generation is draft-first
- nothing is allowed to auto-publish by default

## Before using

1. Review every `config.json`
2. Review every `docker-compose.json`
3. Replace placeholder image names, repositories, and metadata as needed
4. Replace the `foodtruck-content-ops` image with your real built image
5. Add this repo as a custom app store in RunTipi
6. Update the app store in RunTipi
7. Install apps in this order:
   - wrapess-ghost
   - sloppyhero-ghost
   - wrapess-cat
   - sloppyhero-cat
   - foodtruck-content-ops

## Suggested domain map

- `wrapess.com` -> `wrapess-ghost`
- `sloppyhero.com` -> `sloppyhero-ghost`

Optional protected admin domains:
- `cat-wrapess.<your-admin-domain>` -> `wrapess-cat`
- `cat-sloppyhero.<your-admin-domain>` -> `sloppyhero-cat`

## Important

This repo is a starter, not a promise that every image tag and every app option is perfect for your exact environment. Use it as the runway, then let Codex harden and finish it.

## Compatibility note
Some RunTipi docs use `dynamic_config` in examples while other reference pages mention `dynamic`. This starter uses `dynamic_config`, because that is the field shown in the custom app-store guide. If your validator expects `dynamic` instead, swap the field name accordingly.
