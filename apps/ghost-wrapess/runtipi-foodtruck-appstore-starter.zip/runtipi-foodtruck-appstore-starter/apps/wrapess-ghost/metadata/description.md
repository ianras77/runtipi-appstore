# Wrapess Ghost

Public Ghost app for the Wrapess publication.

## What it includes
- Ghost
- dedicated MySQL sidecar
- persistent content storage
- forced public exposure

## Intended public domain
`wrapess.com`

## After install
- expose on `wrapess.com`
- upload the Wrapess theme
- configure members, newsletters, and tiers
- connect Stripe
- add Mailgun for bulk newsletter delivery
- import starter pages and posts
