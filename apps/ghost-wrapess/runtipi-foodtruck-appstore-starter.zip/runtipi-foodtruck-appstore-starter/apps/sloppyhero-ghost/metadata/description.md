# SloppyHero Ghost

Public Ghost app for the SloppyHero publication.

## What it includes
- Ghost
- dedicated MySQL sidecar
- persistent content storage
- forced public exposure

## Intended public domain
`sloppyhero.com`

## After install
- expose on `sloppyhero.com`
- upload the SloppyHero theme
- configure members, newsletters, and tiers
- connect Stripe
- add Mailgun for bulk newsletter delivery
- import starter pages and posts
