# Foodtruck Content Ops

Internal worker app for the Wrapess and SloppyHero stack.

## Purpose
- fetch briefs from each Cat
- validate draft safety and topical fit
- create Ghost drafts through the Admin API
- keep everything draft-first

## Defaults
- `AUTO_PUBLISH=false`
- `EDITORIAL_REVIEW_REQUIRED=true`

## Replace before production
Update the image name in `docker-compose.json` to your real built worker image.
