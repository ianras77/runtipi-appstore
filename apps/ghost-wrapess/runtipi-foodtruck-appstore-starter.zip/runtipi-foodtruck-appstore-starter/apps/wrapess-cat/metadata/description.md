# Wrapess Cat

Private Cheshire Cat instance dedicated to Wrapess.

## What it includes
- Cheshire Cat core
- Qdrant vector memory
- persistent plugin/data volumes

## Purpose
Generate source-backed briefs, outlines, draft payloads, and refresh ideas for Wrapess only.

## Security
Do not expose publicly until:
- API keys are set
- JWT secret is set
- admin users are hardened
