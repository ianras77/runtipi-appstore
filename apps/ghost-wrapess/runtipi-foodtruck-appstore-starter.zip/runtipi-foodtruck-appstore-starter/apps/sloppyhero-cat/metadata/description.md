# SloppyHero Cat

Private Cheshire Cat instance dedicated to SloppyHero.

## What it includes
- Cheshire Cat core
- Qdrant vector memory
- persistent plugin/data volumes

## Purpose
Generate source-backed briefs, outlines, draft payloads, and refresh ideas for SloppyHero only.

## Security
Do not expose publicly until:
- API keys are set
- JWT secret is set
- admin users are hardened
