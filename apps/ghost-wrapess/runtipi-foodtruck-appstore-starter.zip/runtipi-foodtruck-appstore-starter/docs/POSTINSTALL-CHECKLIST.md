# Post-install Checklist

## Ghost
- [ ] Domain resolves correctly
- [ ] HTTPS works
- [ ] Admin login works
- [ ] Theme uploaded
- [ ] Navigation configured
- [ ] Memberships enabled
- [ ] Newsletter enabled
- [ ] Stripe connected
- [ ] Mailgun configured
- [ ] Starter pages created
- [ ] Starter posts imported as drafts
- [ ] Search Console verified
- [ ] Sitemap submitted

## Cheshire Cat
- [ ] Admin reachable locally
- [ ] API key set
- [ ] Plugin loaded
- [ ] Brand policy settings loaded
- [ ] Brief endpoint works
- [ ] Draft endpoint works
- [ ] Refresh endpoint works

## Worker
- [ ] Health endpoint works
- [ ] Queue storage persists
- [ ] Can read from Cat
- [ ] Can create Ghost drafts
- [ ] Auto publish disabled
- [ ] QA blocks unsafe content