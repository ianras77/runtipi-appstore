# Installation Outline

## 1. Add the custom app store
In RunTipi:
- Settings
- App Stores
- Add App Store
- paste your GitHub repository URL

## 2. Update app stores
Use the RunTipi UI to refresh app stores after pushing changes.

## 3. Install public Ghost apps
Install:
- wrapess-ghost
- sloppyhero-ghost

Expose them on:
- wrapess.com
- sloppyhero.com

## 4. Install AI apps
Install:
- wrapess-cat
- sloppyhero-cat

Keep them internal first. Expose later only if you really need remote admin access.

## 5. Install worker app
Install:
- foodtruck-content-ops

This app should remain internal.

## 6. Post-install on Ghost
For each site:
- create owner account
- import theme zip
- set publication info
- create members/newsletters/tiers
- connect Stripe
- connect Mailgun for bulk newsletters
- create navigation
- seed pages and tags
- import starter content as drafts

## 7. Connect worker secrets
Set:
- Ghost admin API URLs and keys
- Cat URLs and API keys
- provider keys for LLM and embeddings