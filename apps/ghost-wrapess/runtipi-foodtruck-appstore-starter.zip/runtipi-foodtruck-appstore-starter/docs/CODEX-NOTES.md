# Codex Notes

Use this starter as a structural reference, not the final word.

Codex should:
- review image tags
- validate RunTipi JSON fields against the current validator
- harden health checks
- add brand-specific Cheshire Cat plugins
- build the real content-ops image
- connect Ghost theme build outputs to deployment
- add docs for user-config overrides and backups